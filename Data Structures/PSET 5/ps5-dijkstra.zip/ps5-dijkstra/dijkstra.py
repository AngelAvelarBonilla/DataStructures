import heap_id

def node_by_name(nodes, city, state):
    return 'NOT IMPLEMENTED'

def distance(node1, node2):
    return 'NOT IMPLEMENTED'

def shortest_path(nodes, edges, weight, s, t):
    return 'NOT IMPLEMENTED'
